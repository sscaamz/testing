# Strawberry FullLTO V4L2 — ready-to-run GitHub Actions kit

No GitHub Actions build has been launched by this delivery. There are no completed
kernel/module binaries in this kit. The original local build reached the FullLTO
link and was killed by the 8 GiB limit. This kit carries forward that exact source
revision, reviewed configuration, original firmware fingerprints, and build fixes.

## Minimal remaining steps in GitHub

1. Create a new **public** repository, for example `strawberry-v4l2-build`.
2. Upload the contents of this directory at the repository root. Preserve the hidden
   `.github/workflows/build.yml` directory/file. GitHub's Add file > Upload files can
   upload folders; if your file picker hides `.github`, create that one file using
   Add file > Create new file and paste the included workflow there. Commit to the
   default branch. This kit has no push trigger, so uploading does not run a build.
3. Confirm free artifact storage and enforce a stop-spending budget in GitHub Billing
   (or confirm there is no payment method, so excess usage is blocked). Then open
   **Actions > Strawberry FullLTO V4L2 > Run workflow**, check the free-storage
   confirmation, and run it once. No local compilation or dependency setup is needed.
4. If successful, download `strawberry-v4l2-exp1` from that run's Artifacts section.
   It contains `strawberry-v4l2-exp1.tar.gz`, which includes bzImage, v4l2loopback.ko,
   .config, Module.symvers, build-report.txt, verification, logs, and matching
   original in-tree modules. Artifacts are retained for only ONE DAY: download them.
   Failure produces a diagnostic-log artifact instead, never claimed-success binaries.

A public repository makes the included build scripts, configs, hashes and workflow
visible. The configs contain original generic build paths; inspect before publishing.
The kit deliberately does not commit firmware bytes, original kernel binaries, private
files, account identifiers, credentials or secrets. It downloads the already-public
original kernel release and verifies its exact SHA-256, then recovers and verifies all
12 firmware files inside the runner. No new firmware source or substitution is used.

## Free-only controls and limitations

- Only `ubuntu-24.04`, the standard x64 runner, is selected. No larger/paid runner,
  service, subscription, cache, Render deployment or upgrade is configured.
- The job is skipped in private repositories. GitHub documents 16 GB RAM/4 CPUs for
  this public runner; private Ubuntu runners have 8 GB. Actual RAM is checked before
  the build, and the job fails if it has less than roughly 14 GB.
- Standard public-runner compute is free. Artifact storage has a shared allowance;
  public compute being free does NOT establish unlimited free artifact storage.
  This integration could not inspect the account's billing usage/budgets. The
  workflow therefore defaults to not running until free storage is confirmed.
- One run at a time, manual trigger only, 300-minute timeout, no caches, successful
  archive capped at 100 MiB, one-day artifact retention. These limits reduce storage
  but do not independently guarantee zero charges without account spending controls.
- A 16 GB runner is an opportunity to complete the FullLTO link, not a guarantee.
  No feature-reducing fallback is implemented if it also runs out of memory.
- Toolchain check requires Clang/LLD 18.1.3. If Ubuntu no longer supplies that version,
  the workflow fails clearly instead of silently changing the compiler.
- Source revision, loopback revision and original binary hashes are fixed. APT host
  dependencies and action major versions can update, so this is an auditable pinned
  kernel recipe, not a promise of bit-for-bit reproducible host tooling or output.

## Preserved baseline and verification

Source: https://github.com/vnkgdshrr/linux-rmuxnet
Commit: 590e14c0f523fb9dd987653b418899d157c8ca3b
Loopback: https://github.com/v4l2loopback/v4l2loopback
Commit: 0f9ee86760b7f2bea174b7e3e7a1d38845da0ab4 (v0.15.4)
Release: 7.1.7-Strawberry-General-FullLTO-v4l2-exp1+

250 Hz, FullLTO, original PS4 CPU/GPU/Belize support, scheduler/power settings and
original enabled features are preserved. The prior reviewed config is carried as
inputs/build.config. Only unused Rust toolchain probe variations are allowed during
Kconfig normalization; any other drift fails the build. The final report lists every
change against inputs/original.config, including newly visible disabled media entries
and mandatory media-controller/USB-audio integration inherited from this tree's Kconfig.

The source baseline is experimentally authorized; exact original source provenance is
still unproven. Prior comparison found all 1,008 comparable tracked original archive
source files identical to this revision. There are no Crashnt source/driver changes.

Post-build checks re-extract the compiled image's config and firmware, verify all 12
firmware byte fingerprints, require the expected release, check .ko architecture and
vermagic, and resolve all module undefined symbols against the completed Module.symvers.
A normal kernel/module build with modpost must pass; no forced loading or missing-symbol
workaround is used. Binaries are packaged only after all checks pass.

Static verification does not prove PS4 boot, OBS operation or retained performance.
Those require hardware testing. This kit never accesses or installs onto your PS4.

## Connector capability findings

The initial repository and installation listings were empty. A subsequent owner-specific
lookup found three public repositories, with reported write/admin permissions, including
sscaamz/testing. Exposed tools include file/blob/tree/commit operations, but no
create-repository action or workflow_dispatch action. Workflow-file write permission
itself has not been tested by a mutation. Workflow rerun tools apply to existing runs.
No repository was created, no files were published, and no workflow was executed.
Publishing the concrete kit to an existing public repository and using a browser
fallback to inspect billing/trigger the workflow awaits user approval. No connector
credentials were sought or taken for shell use.

## Official references checked 6 November 2026

https://docs.github.com/en/actions/reference/runners/github-hosted-runners
https://docs.github.com/en/billing/concepts/product-billing/github-actions
https://docs.github.com/en/billing/reference/product-usage-included
