from pathlib import Path
import json,sys

def config(path):
 d={}
 for l in Path(path).read_text().splitlines():
  if l.startswith('CONFIG_'):
   k,v=l.split('=',1);d[k]=v
  elif l.startswith('# CONFIG_') and l.endswith(' is not set'):d[l[2:-11]]='n'
 return d

def audit(path):
 actual=config(path);expected=config('inputs/build.config');original=config('inputs/original.config')
 # Rust is not an enabled kernel feature; these values probe the host toolchain.
 differences={k:[expected.get(k),actual.get(k)] for k in expected.keys()|actual.keys() if expected.get(k)!=actual.get(k)}
 forbidden={k:v for k,v in differences.items() if not k.startswith('CONFIG_RUSTC_')}
 assert not forbidden, f'Unreviewed config drift: {forbidden}'
 for k,v in original.items():
  if v in ('y','m') and not k.startswith('CONFIG_RUSTC_'):assert actual.get(k)==v,(k,v,actual.get(k))
 for k in ('CONFIG_HZ_250','CONFIG_LTO_CLANG_FULL','CONFIG_PS4_CPUFREQ','CONFIG_X86_PS4','CONFIG_MEDIA_SUPPORT','CONFIG_MEDIA_CAMERA_SUPPORT','CONFIG_VIDEO_DEV'):assert actual[k]=='y',k
 assert actual['CONFIG_HZ']=='250'
 Path('logs/runner-config-probe-differences.json').write_text(json.dumps(differences,indent=2)+'\n')
 print('PASS: exact previously reviewed config, except disclosed unused Rust probes; no original enabled feature removed')
if __name__=='__main__':audit(sys.argv[1])
