#!/usr/bin/env bash
set -euo pipefail
ROOT=$(pwd)
export PATH="/usr/lib/llvm-18/bin:$PATH"
export KBUILD_BUILD_USER=strawberry-v4l2 KBUILD_BUILD_HOST=experimental-build
export KBUILD_BUILD_TIMESTAMP='2026-11-06 00:00:00 +0000'
export KBUILD_BUILD_VERSION=1
SOURCE=590e14c0f523fb9dd987653b418899d157c8ca3b
LOOPBACK=0f9ee86760b7f2bea174b7e3e7a1d38845da0ab4
RELEASE=7.1.7-Strawberry-General-FullLTO-v4l2-exp1+
mkdir -p logs dist work
clang --version | tee logs/toolchain.txt
ld.lld --version | tee -a logs/toolchain.txt
pahole --version | tee -a logs/toolchain.txt
clang --version | head -1 | grep -q '18.1.3'
ld.lld --version | grep -q '18.1.3'
git clone --depth=1 --branch zaebiz/7.1.7-Stable https://github.com/vnkgdshrr/linux-rmuxnet.git work/linux
if [ "$(git -C work/linux rev-parse HEAD)" != "$SOURCE" ]; then
  git -C work/linux fetch --depth=1 origin "$SOURCE"
  git -C work/linux checkout --detach "$SOURCE"
fi
test "$(git -C work/linux rev-parse HEAD)" = "$SOURCE"
git clone --depth=1 --branch v0.15.4 https://github.com/v4l2loopback/v4l2loopback.git work/loopback
test "$(git -C work/loopback rev-parse HEAD)" = "$LOOPBACK"
curl --fail --location --retry 3 --output work/original-bzImage https://github.com/X-F1REBALL-X/PS4-Linux/releases/download/v1.0/bzImage-belize-7.1.7
echo '072113898347932c34888cfdc7556953ee27233c0727cc45f419a57119242480  work/original-bzImage' | sha256sum --check
/usr/bin/python3 scripts/prepare.py
mkdir -p work/out
cp inputs/build.config work/out/.config
make -C work/linux O="$ROOT/work/out" LLVM=1 olddefconfig 2>&1 | tee logs/configure.log
/usr/bin/python3 scripts/audit.py work/out/.config | tee logs/config-audit.txt
work/linux/scripts/diffconfig inputs/original.config work/out/.config > logs/config-diff.txt
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libjemalloc.so.2
export MALLOC_CONF='narenas:1,dirty_decay_ms:0,muzzy_decay_ms:0,background_thread:false'
# Limit only host linker concurrency; retain FullLTO and default target optimization.
make -C work/linux O="$ROOT/work/out" LLVM=1 LD='ld.lld --threads=1 --lto-partitions=1' -j2 bzImage modules 2>&1 | tee logs/kernel-build.log
test "$(cat work/out/include/config/kernel.release)" = "$RELEASE"
test -s work/out/Module.symvers
make -C work/linux O="$ROOT/work/out" LLVM=1 LD='ld.lld --threads=1 --lto-partitions=1' M="$ROOT/work/loopback" modules 2>&1 | tee logs/loopback-build.log
/usr/bin/python3 scripts/verify.py | tee logs/verification.txt
make -C work/linux O="$ROOT/work/out" LLVM=1 INSTALL_MOD_PATH="$ROOT/dist/modules" INSTALL_MOD_STRIP=1 modules_install 2>&1 | tee logs/modules-install.log
rm -f "dist/modules/lib/modules/$RELEASE/build" "dist/modules/lib/modules/$RELEASE/source"
cp work/out/arch/x86/boot/bzImage dist/bzImage
cp work/loopback/v4l2loopback.ko dist/v4l2loopback.ko
mkdir -p "dist/modules/lib/modules/$RELEASE/extra"
cp dist/v4l2loopback.ko "dist/modules/lib/modules/$RELEASE/extra/"
depmod -b "$ROOT/dist/modules" -F work/out/System.map "$RELEASE"
cp work/out/.config dist/.config
cp work/out/Module.symvers work/out/System.map dist/
cp logs/config-diff.txt logs/verification.json dist/
/usr/bin/python3 scripts/report.py
cp -a logs dist/logs
cp INSTALLATION.txt dist/
(cd dist; find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS)
tar -czf work/strawberry-v4l2-exp1.tar.gz -C dist .
# Limit artifact storage; never upload the multi-GB build tree or caches.
test "$(stat -c %s work/strawberry-v4l2-exp1.tar.gz)" -le 104857600
mv work/strawberry-v4l2-exp1.tar.gz dist/
