from pathlib import Path
import json,subprocess
from recover_inputs import unpack, firmware
_,elf,config,_,_=unpack('work/original-bzImage','zstd')
assert config==Path('inputs/original.config').read_bytes(), 'Original config mismatch'
entries=firmware(elf,Path('work/original-firmware'))
assert entries==json.loads(Path('inputs/firmware-manifest.json').read_text()), 'Firmware mismatch'
destination='/home/runner/work/linux/linux/kernel-source-host/extra_firmware'
subprocess.run(['sudo','mkdir','-p',destination],check=True)
subprocess.run(['sudo','cp','-a','work/original-firmware/.',destination+'/'],check=True)
Path('logs/firmware-input-verification.json').write_text(json.dumps(entries,indent=2)+'\n')
