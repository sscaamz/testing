#!/usr/bin/env python3
"""Recover configuration and built-in firmware from the supplied kernels.

Requires Python 3 and zstandard. Does not modify either input or build a kernel.
Usage: python3 recover_inputs.py CRASHNT_BZIMAGE STRAWBERRY_BZIMAGE OUTPUT_DIR
"""
import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import struct
import sys
import zlib
import zstandard


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unpack(path, compression):
    image = Path(path).read_bytes()
    if compression == 'zstd':
        offset = image.index(b'\x28\xb5\x2f\xfd')
        decoder = zstandard.ZstdDecompressor().decompressobj()
        elf = decoder.decompress(image[offset:])
        assert decoder.eof
    elif compression == 'xz':
        offset = image.index(b'\xfd7zXZ\0')
        elf = lzma.decompress(image[offset:])
    else:
        offset = -1
        while True:
            offset = image.index(b'\x1f\x8b\x08', offset+1)
            try:
                elf = zlib.decompress(image[offset:], 31)
            except zlib.error:
                continue
            if elf.startswith(b'\x7fELF'):
                break
    assert elf[:6] == b'\x7fELF\x02\x01'
    marker = elf.index(b'IKCFG_ST')
    decoder = zlib.decompressobj(31)
    config = decoder.decompress(elf[marker+8:])
    assert decoder.eof and decoder.unused_data.startswith(b'IKCFG_ED')
    return image, elf, config, offset, marker


def firmware(elf, destination):
    shoff = struct.unpack_from('<Q', elf, 40)[0]
    entsize, count, string_index = struct.unpack_from('<HHH', elf, 58)
    sections = [struct.unpack_from('<IIQQQQIIQQ', elf, shoff+i*entsize)
                for i in range(count)]
    strings = sections[string_index]
    names = elf[strings[4]:strings[4]+strings[5]]

    def readva(address, size):
        for section in sections:
            if (section[1] != 8 and section[3] <= address
                    and address+size <= section[3]+section[5]):
                offset = section[4]+address-section[3]
                return elf[offset:offset+size]
        raise ValueError('Address outside file-backed ELF sections')

    fw = next(s for s in sections
              if names[s[0]:].split(b'\0', 1)[0] == b'.builtin_fw')
    assert fw[5] % 24 == 0
    entries = []
    for offset in range(fw[4], fw[4]+fw[5], 24):
        nameva, datava, size = struct.unpack_from('<QQQ', elf, offset)
        name = readva(nameva, 256).split(b'\0', 1)[0].decode()
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        data = readva(datava, size)
        path = destination / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        entries.append(dict(name=name, size=size, sha256=sha(data)))
    return entries


def main():
    crashnt, strawberry, output = sys.argv[1:]
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    result = {}
    for label, path, compression in [('crashnt', crashnt, 'xz'),
                                     ('strawberry', strawberry, 'zstd')]:
        image, elf, config, offset, marker = unpack(path, compression)
        (output / (label+'.original.config')).write_bytes(config)
        result[label] = dict(image_size=len(image), image_sha256=sha(image),
                             compression=compression, payload_offset=offset,
                             decompressed_size=len(elf),
                             decompressed_sha256=sha(elf),
                             ikconfig_offset_in_elf=marker,
                             config_size=len(config), config_sha256=sha(config))
        if label == 'strawberry':
            entries = firmware(elf, output / 'strawberry-original-firmware')
            (output / 'strawberry.embedded-firmware.json').write_text(
                json.dumps(entries, indent=2)+'\n')
    (output / 'inspection-results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
