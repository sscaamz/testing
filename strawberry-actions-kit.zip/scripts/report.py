from pathlib import Path
import os,json
v=json.loads(Path('logs/verification.json').read_text())
report='''EXPERIMENTAL STRAWBERRY 7.1.7 V4L2 BUILD
Source: https://github.com/vnkgdshrr/linux-rmuxnet
Commit: 590e14c0f523fb9dd987653b418899d157c8ca3b
Loopback: https://github.com/v4l2loopback/v4l2loopback
Commit: 0f9ee86760b7f2bea174b7e3e7a1d38845da0ab4 (v0.15.4)
Exact original source provenance remains unproven; experimental baseline authorized.
Previously, 1,008 comparable original archive source files matched this revision.
No tracked target-source modifications; FullLTO, 250 Hz, original PS4 features retained.
The original firmware is recovered from the checksum-verified public original kernel.
All 12 firmware entries in the compiled kernel were verified by name, length and SHA-256.
All original enabled features preserved. Every config change appears below.
The unmodified Kconfig adds the media controller, V4L2 I2C support, and integration
with the existing USB audio driver. Physical capture/sensor/tuner drivers stay disabled.
Unused Rust toolchain capability probes may differ; see logs for the exact changes.

Host linking: LLD --threads=1 --lto-partitions=1; make -j2; jemalloc with one arena,
immediate dirty/muzzy decay. No lowered optimization, feature removal, or ThinLTO.
Complete kernel build and normal module modpost required; no forced loading or
unresolved-symbol workaround. Static checks do not establish PS4 hardware behavior.
No boot, OBS, GPU, or performance test occurred. Bootability is NOT guaranteed.

'''
report+='Workflow run: https://github.com/'+os.environ.get('GITHUB_REPOSITORY','')+'/actions/runs/'+os.environ.get('GITHUB_RUN_ID','')+'\n'
report+='Release: '+v['release']+'\n\n'+Path('logs/toolchain.txt').read_text()
report+='\nCONFIG DIFFERENCES:\n'+Path('logs/config-diff.txt').read_text()
report+='\nSTATIC VERIFICATION:\n'+json.dumps(v,indent=2)+'\n'
Path('dist/build-report.txt').write_text(report)
