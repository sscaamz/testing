from pathlib import Path
import json,hashlib,subprocess
from recover_inputs import unpack,firmware
from audit import audit
release=Path('work/out/include/config/kernel.release').read_text().strip()
assert release=='7.1.7-Strawberry-General-FullLTO-v4l2-exp1+'
audit('work/out/.config')
bzimage,elf,config,_,_=unpack('work/out/arch/x86/boot/bzImage','zstd')
assert config==Path('work/out/.config').read_bytes()
actual=firmware(elf,Path('work/verified-firmware'))
expected=json.loads(Path('inputs/firmware-manifest.json').read_text())
assert {e['name']:(e['size'],e['sha256']) for e in actual}=={e['name']:(e['size'],e['sha256']) for e in expected}
ko=Path('work/loopback/v4l2loopback.ko')
undefined=[l.split()[-1] for l in subprocess.check_output(['llvm-nm','--undefined-only',str(ko)],text=True).splitlines() if l.strip()]
exports={l.split()[1] for l in Path('work/out/Module.symvers').read_text().splitlines()}
missing=sorted(set(undefined)-exports)
assert not missing,missing
vermagic=subprocess.check_output(['modinfo','-F','vermagic',str(ko)],text=True).strip()
assert vermagic.startswith(release+' '),vermagic
assert subprocess.check_output(['modinfo','-F','depends',str(ko)],text=True).strip()=='', 'Unexpected module dependencies; V4L2 should be built in'
header=subprocess.check_output(['llvm-readelf','-h',str(ko)],text=True)
assert 'X86-64' in header
# Check all generated in-tree modules as well, before the installed copy is stripped.
module_checks=[]
for p in Path('work/out').rglob('*.ko'):
 names={l.split()[-1] for l in subprocess.check_output(['llvm-nm','--undefined-only',str(p)],text=True).splitlines() if l.strip()}
 assert not names-exports,(str(p),names-exports)
 assert subprocess.check_output(['modinfo','-F','vermagic',str(p)],text=True).startswith(release+' ')
 module_checks.append(str(p))
results={'release':release,'embedded_config_matches':True,'all_12_embedded_firmware_match':True,'kernel_sha256':hashlib.sha256(bzimage).hexdigest(),'module_sha256':hashlib.sha256(ko.read_bytes()).hexdigest(),'vermagic':vermagic,'undefined_symbols':undefined,'missing_exports':missing,'verified_in_tree_modules':module_checks,'hardware_tested':False}
Path('logs/verification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
